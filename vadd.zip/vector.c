/*
Shreyash Pardikar
PF62

*/
#include<stdio.h>
#include<omp.h>
#include<stdlib.h>

void filegenerator(int n,char a[])
{
	FILE *fptr;
	fptr=fopen(a, "w");
	int x;
	for(int i=0;i<n;i++)
	{
		x=rand()%100;
		fprintf(fptr," %d \n",x);	
	}
	fclose(fptr);		
}

void addition(char a[],char b[],char c[],int n)
{
	FILE *fptr1,*fptr2,*fptr3,*fptr;
	fptr1=fopen(a, "r");
	fptr2=fopen(b, "r");
	fptr3=fopen(c, "w");
	int in1,in2;	
	int output;
	#pragma parallel omp for private(i) 
	for(int i=0;i<n;i++)
	{
		fscanf(fptr1, "%d", &in1);
		fscanf(fptr2, "%d", &in2);
		output=in1-in2;
		fprintf(fptr3," %d \n",output);	
	}
	fclose(fptr1);
	fclose(fptr2);
	fclose(fptr3);
	
}

int main()
{
	int n;
	printf("enter number of elements:\n");
	scanf("%d",&n);
	filegenerator(n,"f1.txt");
	filegenerator(n,"f2.txt");
	FILE *fptr1,*fptr2,*fptr3; 
	fptr1 = fopen("f1.txt","r");
	fptr2 = fopen("f2.txt","r");
	
	addition("f1.txt","f2.txt","f3.txt",n);
	printf("\nResult stored in f3 \n");
	return 0;
}


/*

OUTPUT:

student@student:~/Desktop$ gcc vectoradd.c -fopenmp
student@student:~/Desktop$ ./a.out
enter number of elements:
5

Result stored in f3

*/

